import React from 'react';
import { Check } from 'lucide-react';
import { getToolWorkflowDefinition } from '../utils/studioLogic';
import type { StudioTool, WizardStep } from '../types/studio';

interface WizardStepperProps {
  activeTool: StudioTool;
  currentStep: WizardStep;
  maxReachedStep: WizardStep;
  onSelectStep: (step: WizardStep) => void;
  isProcessing: boolean;
}

export const WizardStepper: React.FC<WizardStepperProps> = ({
  activeTool,
  currentStep,
  maxReachedStep,
  onSelectStep,
  isProcessing,
}) => {
  const workflow = getToolWorkflowDefinition(activeTool);
  const currentIdx = workflow.steps.findIndex((s) => s.id === currentStep);
  const maxIdx = workflow.steps.findIndex((s) => s.id === maxReachedStep);

  return (
    <nav aria-label={`${workflow.nameMy} လုပ်ငန်းစဉ် အဆင့်များ`} className="mb-6">
      <ol
        data-testid={`stepper-${activeTool}`}
        className={`grid gap-2 ${
          workflow.steps.length === 5
            ? 'grid-cols-3 sm:grid-cols-5'
            : 'grid-cols-3 sm:grid-cols-6'
        }`}
      >
        {workflow.steps.map((item, idx) => {
          const isCurrent = item.id === currentStep;
          const isDone = currentIdx > idx;
          const canJump =
            !isProcessing &&
            item.id !== 5 &&
            (idx <= maxIdx || item.id <= maxReachedStep) &&
            !isCurrent;

          return (
            <li key={`${activeTool}-${item.id}`}>
              <button
                type="button"
                disabled={!canJump}
                onClick={() => canJump && onSelectStep(item.id)}
                aria-current={isCurrent ? 'step' : undefined}
                className={`flex w-full items-center gap-1.5 sm:gap-2 rounded-xl border px-2 sm:px-3 py-2 text-left transition-all ${
                  isCurrent
                    ? 'border-blue-500/70 bg-blue-600/20 text-white blue-glow-ring'
                    : isDone
                      ? 'border-blue-500/30 bg-[#10141D] text-slate-200 hover:border-blue-400/50 cursor-pointer'
                      : 'border-white/10 bg-[#10141D]/60 text-slate-500'
                }`}
              >
                <span
                  className={`flex h-5 w-5 sm:h-6 sm:w-6 shrink-0 items-center justify-center rounded-lg text-[11px] sm:text-xs font-bold font-mono-tabular ${
                    isCurrent
                      ? 'bg-blue-600 text-white'
                      : isDone
                        ? 'bg-blue-500/20 text-blue-300'
                        : 'bg-white/5 text-slate-500'
                  }`}
                >
                  {isDone ? <Check className="h-3 w-3 sm:h-3.5 sm:w-3.5" /> : item.displayNum}
                </span>
                <span className="min-w-0 truncate text-[11px] sm:text-xs font-medium">
                  {item.shortLabel}
                </span>
              </button>
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

