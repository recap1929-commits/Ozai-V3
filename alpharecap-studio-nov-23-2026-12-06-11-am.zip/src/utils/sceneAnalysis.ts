import type { SceneAnalysisProvider, SceneSummary } from '../types/studio';
import { extractErrorText, isModelNotFoundError, isQuotaRateLimitError, isTransientNetworkError } from './retry';

export const GROQ_VISION_MAX_IMAGES_PER_REQUEST = 3;

export const PROVIDER_STATUS_MY = {
  geminiActive: 'Gemini API အသုံးပြုနေသည်',
  geminiDone: 'Gemini API ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ',
  switchingToGroq: 'Groq AI သို့ အလိုအလျောက် ပြောင်းလဲနေသည်',
  groqDone: 'Groq AI ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ',
  bothUnavailable:
    'Gemini API နှင့် Groq AI နှစ်ခုလုံး ခေတ္တအသုံးပြု၍မရပါ — ပြီးစီးထားသော Scene များကို သိမ်းဆည်းထားပြီး ခေတ္တစောင့်၍ ပြန်စစ်ဆေးနိုင်ပါသည်',
} as const;

export interface ExtractedFrameMeta {
  index: number;
  timestamp: number;
  imageUrl: string;
  jpgPath: string;
  ppmBytes?: Uint8Array | null;
}

export interface SceneAnalysisCheckpoint {
  videoSignature: string;
  frames: Array<{ index: number; timestamp: number; imageUrl: string; filename: string }>;
  completedScenes: SceneSummary[];
  storyAnalysisMy: string;
  activeProvider: SceneAnalysisProvider;
  fallbackUsed: boolean;
  groqVisionModel: string | null;
  status: 'in_progress' | 'completed' | 'error';
  lastErrorMy?: string;
  updatedAt: number;
}

/**
 * Computes evenly spaced representative timestamps across the full video [0.25s .. duration - 0.25s],
 * avoiding 0.00s fade-in black frames while covering beginning, middle, and ending chronologically.
 */
export function computeRepresentativeFrameTimestamps(
  durationSeconds: number,
  options?: { minFrames?: number; maxFrames?: number; intervalSeconds?: number }
): number[] {
  const safeDur = Number.isFinite(durationSeconds) && durationSeconds > 0 ? durationSeconds : 12;
  const minFrames = Math.max(2, options?.minFrames ?? 4);
  const maxFrames = Math.max(minFrames, options?.maxFrames ?? 20);
  const interval = Math.max(1.2, options?.intervalSeconds ?? 2.5);

  const count = Math.min(maxFrames, Math.max(minFrames, Math.round(safeDur / interval)));
  if (safeDur <= 1.2) {
    return [Number((safeDur * 0.25).toFixed(2)), Number((safeDur * 0.75).toFixed(2))];
  }

  const startPad = Math.min(0.4, safeDur * 0.04);
  const endPad = Math.min(0.4, safeDur * 0.04);
  const span = Math.max(0.4, safeDur - startPad - endPad);

  const timestamps: number[] = [];
  for (let i = 0; i < count; i++) {
    const ratio = count === 1 ? 0.5 : i / (count - 1);
    const ts = Number((startPad + ratio * span).toFixed(2));
    if (timestamps.length === 0 || ts > timestamps[timestamps.length - 1] + 0.05) {
      timestamps.push(ts);
    }
  }
  return timestamps;
}

function parsePpmPixelOffset(bytes: Uint8Array): { offset: number; width: number; height: number } | null {
  if (bytes.length < 16 || bytes[0] !== 0x50 || bytes[1] !== 0x36) return null; // P6 binary PPM
  let idx = 2;
  const tokens: string[] = [];
  while (idx < bytes.length && tokens.length < 3) {
    while (idx < bytes.length && (bytes[idx] === 0x20 || bytes[idx] === 0x0a || bytes[idx] === 0x0d || bytes[idx] === 0x09)) {
      idx++;
    }
    if (idx < bytes.length && bytes[idx] === 0x23) {
      while (idx < bytes.length && bytes[idx] !== 0x0a) idx++;
      continue;
    }
    let tok = '';
    while (
      idx < bytes.length &&
      bytes[idx] !== 0x20 &&
      bytes[idx] !== 0x0a &&
      bytes[idx] !== 0x0d &&
      bytes[idx] !== 0x09
    ) {
      tok += String.fromCharCode(bytes[idx]);
      idx++;
    }
    if (tok) tokens.push(tok);
  }
  if (tokens.length < 3) return null;
  const width = Number(tokens[0]);
  const height = Number(tokens[1]);
  const maxVal = Number(tokens[2]);
  if (!Number.isFinite(width) || !Number.isFinite(height) || maxVal <= 0) return null;
  if (idx < bytes.length) idx++; // skip single whitespace byte after maxVal
  return { offset: idx, width, height };
}

/**
 * Computes normalized mean absolute difference (0..1) between two P6 PPM frames.
 */
export function computePpmFrameDifference(ppmA: Uint8Array | null | undefined, ppmB: Uint8Array | null | undefined): number {
  if (!ppmA || !ppmB) return 1;
  const metaA = parsePpmPixelOffset(ppmA);
  const metaB = parsePpmPixelOffset(ppmB);
  if (!metaA || !metaB || metaA.width !== metaB.width || metaA.height !== metaB.height) {
    return 1;
  }

  const lenA = ppmA.length - metaA.offset;
  const lenB = ppmB.length - metaB.offset;
  const sampleBytes = Math.min(lenA, lenB);
  if (sampleBytes <= 0) return 1;

  let diffSum = 0;
  let count = 0;
  const stride = Math.max(1, Math.floor(sampleBytes / 2400));
  for (let i = 0; i < sampleBytes; i += stride) {
    diffSum += Math.abs(ppmA[metaA.offset + i] - ppmB[metaB.offset + i]);
    count++;
  }
  return count > 0 ? diffSum / (count * 255) : 1;
}

/**
 * Removes consecutive near-duplicate frames while preserving original timestamps and minimum story coverage.
 */
export function deduplicateExtractedFrames<T extends { timestamp: number; ppmBytes?: Uint8Array | null }>(
  frames: T[],
  minDiffThreshold = 0.04,
  minMinimumFrames = 3
): T[] {
  if (frames.length <= minMinimumFrames) {
    return [...frames].sort((a, b) => a.timestamp - b.timestamp);
  }

  const sorted = [...frames].sort((a, b) => a.timestamp - b.timestamp);
  const kept: T[] = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    const candidate = sorted[i];
    const prevKept = kept[kept.length - 1];
    const isLast = i === sorted.length - 1;
    const diff = computePpmFrameDifference(prevKept.ppmBytes, candidate.ppmBytes);
    if (diff >= minDiffThreshold || isLast) {
      // Avoid keeping identical final frame unless we're below minimum coverage
      if (isLast && diff < minDiffThreshold && kept.length >= minMinimumFrames) {
        continue;
      }
      kept.push(candidate);
    }
  }

  // If video is very static and almost all frames were skipped, ensure minimum evenly-spaced timestamps remain
  if (kept.length < Math.min(minMinimumFrames, sorted.length)) {
    const fallbackIndices = new Set<number>([0, Math.floor((sorted.length - 1) / 2), sorted.length - 1]);
    return [...fallbackIndices]
      .sort((a, b) => a - b)
      .map((idx) => sorted[idx]);
  }

  return kept;
}

/**
 * Splits extracted frames into small batches compatible with Groq vision image limits (<= 4 per request).
 */
export function partitionFramesIntoBatches<T>(
  frames: T[],
  batchSize = GROQ_VISION_MAX_IMAGES_PER_REQUEST
): T[][] {
  const safeBatchSize = Math.max(1, Math.min(GROQ_VISION_MAX_IMAGES_PER_REQUEST, Math.floor(batchSize || 3)));
  const batches: T[][] = [];
  for (let i = 0; i < frames.length; i += safeBatchSize) {
    batches.push(frames.slice(i, i + safeBatchSize));
  }
  return batches;
}

/**
 * Merges completed scene summaries into strict chronological order by index/timestamp without duplicates.
 */
export function mergeScenesChronologically(
  existing: SceneSummary[],
  incoming: SceneSummary[]
): SceneSummary[] {
  const byIndex = new Map<number, SceneSummary>();

  for (const sc of existing) {
    if (!sc || typeof sc.index !== 'number' || !String(sc.descriptionMy || '').trim()) continue;
    byIndex.set(sc.index, {
      ...sc,
      timestamp: Number(Number(sc.timestamp || 0).toFixed(2)),
      descriptionMy: String(sc.descriptionMy).trim(),
    });
  }

  for (const sc of incoming) {
    if (!sc || typeof sc.index !== 'number' || !String(sc.descriptionMy || '').trim()) continue;
    byIndex.set(sc.index, {
      ...sc,
      timestamp: Number(Number(sc.timestamp || 0).toFixed(2)),
      descriptionMy: String(sc.descriptionMy).trim(),
    });
  }

  return [...byIndex.values()].sort((a, b) => {
    if (a.timestamp !== b.timestamp) return a.timestamp - b.timestamp;
    return a.index - b.index;
  });
}

/**
 * Determines the earliest batch index that still contains unanalyzed frames so resume skips completed work.
 */
export function computeResumeBatchIndex(
  frames: Array<{ index: number; timestamp: number }>,
  completedScenes: SceneSummary[],
  batchSize = GROQ_VISION_MAX_IMAGES_PER_REQUEST
): number {
  const batches = partitionFramesIntoBatches(frames, batchSize);
  const doneIndices = new Set(
    completedScenes
      .filter((s) => String(s.descriptionMy || '').trim().length > 0)
      .map((s) => s.index)
  );

  for (let b = 0; b < batches.length; b++) {
    const allDone = batches[b].every((frame) => doneIndices.has(frame.index));
    if (!allDone) return b;
  }
  return batches.length;
}

/**
 * Detects Gemini 429 RESOURCE_EXHAUSTED, daily quota exhaustion, or rate-limit errors.
 */
export function isGeminiQuotaExhaustedError(err: unknown): boolean {
  if (isQuotaRateLimitError(err)) return true;
  const text = extractErrorText(err).toLowerCase();
  return (
    text.includes('daily') && text.includes('quota') ||
    text.includes('exceeded your current quota') ||
    text.includes('generativelanguage.googleapis.com/generate_content_free_tier')
  );
}

/**
 * Selects verified Groq vision models actually present on the configured Groq account.
 * Picks qwen/qwen3.8-27b ONLY if available in availableModelIds; never calls unverified unsupported models blindly.
 */
export function selectGroqVisionModelCandidates(availableModelIds: string[]): string[] {
  const cleanAvailable = [...new Set(availableModelIds.map((m) => String(m || '').trim()).filter(Boolean))];
  if (cleanAvailable.length === 0) {
    // Only if model-listing endpoint could not be queried, try standard current Groq multimodal vision models
    return [
      'meta-llama/llama-4-scout-17b-16e-instruct',
      'meta-llama/llama-4-maverick-17b-128e-instruct',
    ];
  }

  const availableSet = new Set(cleanAvailable);
  const selected: string[] = [];
  const pushIfAvailable = (id: string) => {
    if (availableSet.has(id) && !selected.includes(id)) {
      selected.push(id);
    }
  };

  // 1. Requested Qwen vision model only if enabled on account
  pushIfAvailable('qwen/qwen3.8-27b');

  // 2. Any other Qwen vision/VL model present on account
  for (const id of cleanAvailable) {
    if (/qwen.*(?:vl|vision|3\.8)/i.test(id) && !selected.includes(id)) {
      selected.push(id);
    }
  }

  // 3. Verified Groq Llama-4 multimodal vision models (native image_url support)
  pushIfAvailable('meta-llama/llama-4-scout-17b-16e-instruct');
  pushIfAvailable('meta-llama/llama-4-maverick-17b-128e-instruct');

  // 4. Legacy or alternative Groq vision models if still active on account
  pushIfAvailable('llama-3.2-90b-vision-preview');
  pushIfAvailable('llama-3.2-11b-vision-preview');

  for (const id of cleanAvailable) {
    if (/(?:vision|llava|pixtral|multimodal)/i.test(id) && !selected.includes(id)) {
      selected.push(id);
    }
  }

  return selected;
}

export function isProviderAuthError(err: unknown): boolean {
  const text = extractErrorText(err).toLowerCase();
  return (
    text.includes('401') ||
    text.includes('403') ||
    text.includes('invalid_api_key') ||
    text.includes('invalid api key') ||
    text.includes('incorrect api key') ||
    text.includes('unauthorized') ||
    text.includes('permission_denied')
  );
}

export function classifySceneProviderError(
  provider: SceneAnalysisProvider,
  err: unknown
): { kind: 'quota' | 'auth' | 'model_unavailable' | 'transient' | 'other'; errorMy: string } {
  const label = provider === 'gemini' ? 'Gemini API' : 'Groq AI';
  if (isProviderAuthError(err)) {
    return {
      kind: 'auth',
      errorMy: `${label} API Key မှားယွင်းနေပါသည် သို့မဟုတ် သက်တမ်းကုန်နေပါသည် (401 Invalid API Key)`,
    };
  }
  if (isGeminiQuotaExhaustedError(err)) {
    return {
      kind: 'quota',
      errorMy:
        provider === 'gemini'
          ? 'Gemini API 429 Quota ပြည့်သွားပါသည် (RESOURCE_EXHAUSTED)'
          : 'Groq AI Vision Quota / Rate Limit ပြည့်သွားပါသည် — ခေတ္တစောင့်ပြီး ထပ်မံစစ်ဆေးပါ',
    };
  }
  if (isModelNotFoundError(err)) {
    return {
      kind: 'model_unavailable',
      errorMy: `${label} Vision Model ကို အကောင့်တွင် အသုံးပြု၍မရပါ`,
    };
  }
  if (isTransientNetworkError(err)) {
    return {
      kind: 'transient',
      errorMy: `${label} နှင့် ချိတ်ဆက်မှု ယာယီပြတ်တောက်သွားပါသည်`,
    };
  }
  const rawMsg = extractErrorText(err).trim();
  return {
    kind: 'other',
    errorMy: `${label} စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်${rawMsg ? ` (${rawMsg.slice(0, 120)})` : ''}`,
  };
}

export function formatSceneProviderStatusMy(
  provider: SceneAnalysisProvider,
  phase: 'analyzing' | 'switching' | 'completed'
): string {
  if (phase === 'switching') return PROVIDER_STATUS_MY.switchingToGroq;
  if (phase === 'completed') {
    return provider === 'groq' ? PROVIDER_STATUS_MY.groqDone : PROVIDER_STATUS_MY.geminiDone;
  }
  return provider === 'groq' ? PROVIDER_STATUS_MY.switchingToGroq : PROVIDER_STATUS_MY.geminiActive;
}

/**
 * Computes the 90% target narration duration for Movie Recap scripts while preserving key events & dialogue.
 */
export function computeRecapTargetDurationSeconds(videoDurationSeconds: number): number {
  const safe = Math.max(1, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  return Number((safe * 0.9).toFixed(2));
}

export interface RecapPromptInput {
  durationSeconds: number;
  transcript: string;
  voiceStyleName: string;
  voiceStyleTag: string;
  voiceStyleDesc: string;
  speedNote: string;
  beatListText: string;
  beatCount: number;
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
}

/**
 * Builds the Movie Recap prompt enforcing Natural Character Dialogue Integration (all 12 rules)
 * and the 90% target narration duration.
 */
export function buildRecapNaturalDialoguePrompt(input: RecapPromptInput): {
  systemInstruction: string;
  prompt: string;
  targetDurationSeconds: number;
} {
  const targetDurationSeconds = computeRecapTargetDurationSeconds(input.durationSeconds);

  const sceneContextText =
    Array.isArray(input.scenes) && input.scenes.length > 0
      ? input.scenes
          .slice(0, 20)
          .map((sc) => `- [${Number(sc.timestamp || 0).toFixed(1)}s] ${String(sc.descriptionMy || '').trim()}`)
          .join('\n')
      : '';

  const systemInstruction =
    'You are an expert Myanmar Movie Recap storyteller and dialogue adapter. Integrate important original character dialogues (questions/answers, threats/warnings, arguments/confrontations, emotional moments, funny/memorable lines, plot revelations, character decisions/promises) naturally in conversational Burmese inside chronological storytelling narration. Never fabricate missing dialogue; describe observable visual actions faithfully when dialogue is unclear or absent. Maintain the ~90% target narration duration constraint. Never exceed 24 characters for thumbnailTitleMy.';

  const prompt = `Write a NEW FULL Myanmar movie recap narration covering the ${input.durationSeconds.toFixed(2)}s video chronologically from opening scene to climax/ending.
Target Narration Duration: ~${targetDurationSeconds.toFixed(2)} seconds (~90% of the ${input.durationSeconds.toFixed(2)}s original video duration).
Selected Voice Persona Style: ${input.voiceStyleName} (${input.voiceStyleTag}) — ${input.voiceStyleDesc}
${input.transcript ? `\nOriginal Audio Transcript Context:\n"${input.transcript}"\n` : ''}
${input.storyAnalysisMy ? `\nChronological Story Overview:\n${input.storyAnalysisMy}\n` : ''}
${sceneContextText ? `\nVerified Chronological Scene Breakdown:\n${sceneContextText}\n` : ''}
${input.speedNote}

## MOVIE RECAP – NATURAL CHARACTER DIALOGUE INTEGRATION RULES
1. Include important original character dialogues in the Myanmar movie recap narration — do NOT flatten the entire movie into a dry summary.
2. Preserve meaningful conversations that drive the plot forward, prioritizing:
   - Important questions and answers.
   - Threats and warnings.
   - Arguments and confrontations.
   - Emotional conversations.
   - Funny and memorable moments.
   - Important plot revelations.
   - Character decisions and promises.
3. Rewrite dialogue into natural, conversational Myanmar Burmese preserving original meaning and emotion.
4. Use character names when identifiable from the video/transcript (or clear roles like "စုံထောက်ကြီး", "သူငယ်ချင်း", "မင်းသား" if unnamed).
5. Integrate character dialogue naturally into storytelling narration (for example: "သူက 'ငါမင်းကို လုံးဝမယုံဘူး' လို့ ဒေါသတကြီး ပြန်ပြောလိုက်တယ်").
6. Strictly DO NOT invent or hallucinate dialogue that does not exist in the original video or transcript.
7. Skip trivial filler small talk; prioritize meaningful plot-moving dialogue.
8. Preserve strict chronological order and scene continuity from start to finish.
9. Never omit important character dialogue merely to shorten the recap script.
10. Maintain the ~90% target narration duration (${targetDurationSeconds.toFixed(2)}s) by balancing crisp storytelling transitions with preserved dialogue lines around MAX_WORDS per beat.
11. If dialogue transcription is missing or unclear for a beat, DO NOT fabricate spoken lines — write a faithful description of the observable scene instead.

Story Beats Covering Full Video:
${input.beatListText}

Requirements:
1. "segments": Array with EXACTLY ${input.beatCount} items matching each input beat id in order. Each item MUST have: id (string matching input id), myanmarText (natural Myanmar movie recap storytelling + integrated conversational character dialogue), emoji (1 matching emoji like 🔥, 😱, 🎬, 💬).
2. "thumbnailTitleMy": A viral Myanmar thumbnail title STRICTLY under 25 characters (maximum 24 characters).`;

  return { systemInstruction, prompt, targetDurationSeconds };
}
